#pragma once
// Minimal placeholder
